WINHOUSE PROJECT MANAGEMENT - FULL PRODUCTION INTERFACE
Sau khi đăng nhập thành công, hệ thống tải giao diện sử dụng đầy đủ theo quyền tài khoản.
Không dùng bản WINHOUSE_LOGIN_WEB_FINAL nữa vì bản đó chỉ là bước kiểm thử đăng nhập.
Dùng index.html làm trang chính khi triển khai HTTPS.
